function usuarioBanco(conexao){
    this._conexao=conexao;
  }

usuarioBanco.prototype.add = function(dados,callback){
    this._conexao.query('INSERT INTO usuario SET ?',dados,callback);
  }

usuarioBanco.prototype.idbusca = function(dados,callback){
  this._conexao.query('SELECT * FROM usuario WHERE id = ?',[dados.ID],callback);
}

usuarioBanco.prototype.enter = function(dados,callback){
  this._conexao.query('SELECT * FROM usuario WHERE email = ? AND senha = ?',[dados.email, dados.senha],callback);
}

usuarioBanco.prototype.change = function(dados,callback){
  this._conexao.query('UPDATE usuario SET ? WHERE id = ?',[dados, dados.ID],callback)

}

usuarioBanco.prototype.cursos = function(idc,na,callback){
  this._conexao.query('SELECT * FROM aula WHERE IDC = ? AND numaula = ?',[idc,na],callback)
}

module.exports = function(){
    return usuarioBanco;
}