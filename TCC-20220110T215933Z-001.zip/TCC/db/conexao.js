var mysql = require('mysql');
function criarConexao(){

return mysql.createConnection ({
    host:'localhost',
    user: 'root',
    password: '',
    database: 'tcc_ilearn',
    insecureAuth: 'true',
    multipleStatements: 'true'



  });
}
module.exports = function(){
  return criarConexao;
}