function isEmpty(obj) {
    return Object.keys(obj).length === 0;
  }
var login = false
var ide
var express = require('express')
var app = express()
var bodyParser = require('body-parser')
var load = require('express-load')
const { renderFile } = require('ejs')
load('db')
.into(app);

const path = require('path')
const multer = require('multer');
const storage=multer.diskStorage({
  destination:(req,file,cb)=>{
    cb(null,'./uploads')
  },
  filename:(req,file,cb)=>{
    var {name,ext}=path.parse(file.originalname)
    cb(null,`${name}${ext}`)
  }
})
const upload = multer({ storage });

app.set('view engine','ejs')
app.use(express.static('public'))
app.use(bodyParser.urlencoded({extended:true}))
app.use('/uploads', express.static('uploads'))

//AÇOES//

app.get('/register', function(req,res){
    res.render('register.ejs')
})

app.get('/cursos', function(req,res){
    if(login === false){
        res.redirect('/login')
    }else{
       res.render('cursos.ejs',{'login': login})
    }
})

app.get('/login', function(req,res){
    res.render('login.ejs')
})

app.get('/sobre',function(req,res){
    res.render('sobre.ejs',{'login': login})
})

app.get('/perfil',function(req,res){
    if(login === false){
        res.redirect('/login')
    }else{
        res.render('perfil.ejs',{'login': login,'id':ide})

    }
})

app.get('/editar_perfil',function(req,res){
    if(login === false){
        res.redirect('/login')
    }else{
        res.render('editar_perfil.ejs',{'login': login,'id':ide})

    }
})

app.get('/',function(req,res){
    res.render('index.ejs',{'login': login})
})

app.get('/sair',function(req,res){
    login = false
    res.redirect('/')
})

app.get('/aula/:idc/:na',function(req,res){
    var idc = req.params.idc;
    var na = req.params.na;
    var conexao = app.db.conexao();
    var usuarioBanco = new app.db.usuarioBanco(conexao);
    usuarioBanco.cursos(idc,na,function(erro,sucesso){
        if(erro){
            console.log(erro)
        }else{
            fn = sucesso;
            res.render('aula.ejs',{'dados': fn})
        }
    })
})

app.get('/voltar/:idc/:na',function(req,res){
    var idc = req.params.idc;
    var na = req.params.na;
    if(na == 1){
        res.redirect('/')
    }else{
        na = na - 1;
        var conexao = app.db.conexao();
    var usuarioBanco = new app.db.usuarioBanco(conexao);
    usuarioBanco.cursos(idc,na,function(erro,sucesso){
        if(erro){
            console.log(erro)
        }else{
            fn = sucesso;
            res.render('aula.ejs',{'dados': fn})
        }
    })
    }
})

app.get('/comprar',function(req,res){
    res.render('comprar.ejs',{'id':ide})
})

app.get('/proxima/:idc/:na',function(req,res){
    var idc = req.params.idc;
    var na = req.params.na;
    if(na == 3){
        res.render('index.ejs')
    }else{
        na = na + 1;
        var conexao = app.db.conexao();
    var usuarioBanco = new app.db.usuarioBanco(conexao);
    usuarioBanco.cursos(idc,na,function(erro,sucesso){
        if(erro){
            console.log(erro)
        }else{
            fn = sucesso;
            res.render('aula.ejs',{'dados': fn})
        }
    }) 

    }
})


//AÇOES NO DB//

app.post('/cadastrar', function(req, res){
    var dados = req.body;
    var conexao = app.db.conexao();
    var usuarioBanco = new app.db.usuarioBanco(conexao);
    dados.img = 'default-user-image.png';
    usuarioBanco.add(dados,function(erro,sucesso){
        if(erro){
            console.log(erro);
        }
        else{
            res.redirect('/login');
        }
    });
});

app.post('/entrar', function(req,res){
    var dados = req.body;
    var conexao = app.db.conexao();
    var usuarioBanco = new app.db.usuarioBanco(conexao);
    usuarioBanco.enter(dados,function(erro,sucesso){
        if(erro){
            console.log(erro);
        }
        if(isEmpty(sucesso)){
            res.render('login.ejs',{'login': login},{'erro':true})
        }
        else{
            ide = sucesso
            login = true
            res.render('index.ejs',{'login': login});
        }
    });
});

app.post('/alterar', upload.single('img'), function(req, res){
    var dados = req.body
    var conexao = app.db.conexao();
    var usuarioBanco = new app.db.usuarioBanco(conexao);  
    dados.img = req.file.filename;
    usuarioBanco.change(dados,function(erro,sucesso){
        if(erro){
            console.log(erro);
        }
        else{
            usuarioBanco.idbusca(dados,function(erro,sucesso){
                if(erro){
                    console.log(erro)
                }else{
                    ide = sucesso
                    login = true
                    res.render('editar_perfil.ejs',{'login': login,'id': ide})
                }
            })
        }
    });
});

//FIM DAS AÇOES//

var porta=3000
app.listen(porta,function(){
    console.log('Servidor Rodando')
})
