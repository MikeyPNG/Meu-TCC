-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 07-Dez-2021 às 07:34
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tcc_ilearn`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aula`
--

CREATE TABLE `aula` (
  `IDC` int(2) NOT NULL,
  `numaula` int(3) NOT NULL,
  `nomeaula` varchar(30) NOT NULL,
  `link` varchar(150) NOT NULL,
  `descaula` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `aula`
--

INSERT INTO `aula` (`IDC`, `numaula`, `nomeaula`, `link`, `descaula`) VALUES
(1, 1, 'Ferramenta Borracha', 'https://www.youtube.com/embed/?v=LqKO6lDFnPw&list=PLo6f_wFcGpWzN3ACmI0CdQOnreAEipCfE&index=3', 'Durante o estudo desta aula, será apresentado a utilização da ferramenta borracha e borracha mágica, e como utiliza-las para a remoção do fundo de imagens no programa Adobe Photoshop. O maior problema trabalhando com este tipo de imagem, é manter a integridade do cabelo ou de outras áreas que possuem diversos espaços minúsculos que fazem parte do fundo, localizados em áreas difíceis para a seleção e recorte. Em seguida na aula será apresentado como é feita a construção de um fundo, ao produzir um fundo degrade utilizando apenas as ferramentas localizadas no Adobe Photoshop. esse tipo de conhecimento é importante quando editando uma imagem, pois o efeito das cores alteram e muito o quão chamativa uma imagem fica, sendo o fundo uma das áreas mais importantes da imagem se não a mais importante. Esta aula consta com apenas 5 minutos de vídeo disponibilizado por profissionais da área da edição de imagem, ensinando como utilizar ferramentas importantíssimas no dia a dia de um editor profiss'),
(1, 2, 'Desfoque, nitidez, etc', 'https://www.youtube.com/embed/?v=lp15EmT1uFQ&list=PLo6f_wFcGpWzN3ACmI0CdQOnreAEipCfE&index=2', 'A segunda aula demonstra as ferramentas desfoque, nitidez, borrar, subexposição, superexposição, esponja e caneta. Cada par dessa ferramentas possuem semelhanças entre si, por exemplo tanto desfoque e nitidez trabalham com resistência, enquanto tanto subexposição e superexposição trabalham com a mudança da nitidez da imagem.A ferramenta esponja diferente das ultimas 4 citadas, trabalha tanto com a saturação da imagem, quanto com a remoção da saturação da imagem, sendo possivel modificar essa propriedade de tipo de esponja dentro do programa como demonstrado no vídeo. Esta aula consta com apenas 7 minutos de vídeo disponibilizado por profissionais da área da edição de imagem, ensinando como utilizar ferramentas importantíssimas no dia a dia de um editor.'),
(1, 3, 'Degrade', 'https://www.youtube.com/embed/?v=YRk0dznvRog&list=PLo6f_wFcGpWzN3ACmI0CdQOnreAEipCfE&index=1', 'A terceira aula demonstra a ferramenta degrade e seus cinco tipos, sendo eles linear, radial, angular, refletida e diâmetro. Essa ferramenta preenche a area selecionada com uma variação gradativa das cores selecionadas para o mesmo, ela é geralmente utilizada na edição de planos de fundos. De acordo com o tipo de degrade escolhido, é alterado o tipo de padrao utilizado no degrade da imagem, por exemplo aonde é focada cada cor. De acordo com o tamanho do degrade, a quantidade de desfoque na cor aumenta. Nesta aula, voce aprendera a manipular essa ferramenta para a criação de fundos de perfil modificando seu gradiente e sua tonalidade. Esta aula consta com apenas 7 minutos de vídeo disponibilizado por profissionais da área da edição de imagem, ensinando como utilizar ferramentas importantíssimas no dia a dia de um editor profissional.');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `ID` int(2) NOT NULL,
  `img` varchar(40) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `senha` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `ID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
